interface LogoProps {
  className?: string;
  size?: number;
}

export const Logo = ({ className = "", size = 28 }: LogoProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Crescent moon */}
    <path
      d="M32 4a28 28 0 1 0 24.5 41.7A22 22 0 0 1 32 4Z"
      fill="currentColor"
      opacity="0.95"
    />
    {/* Wolf head silhouette overlaid */}
    <path
      d="M20 30c1.5-3 3-5 5-6l-1-4 4 3c2-.5 4-.5 6 0l4-3-1 4c2 1 3.5 3 5 6 .8 1.6 1 3.2.5 4.5l-2-1.5-1 3-2-2c-.8 1-1.8 1.8-3 2.3v3l-2-2-2 2v-3c-1.2-.5-2.2-1.3-3-2.3l-2 2-1-3-2 1.5c-.5-1.3-.3-2.9.5-4.5Z"
      fill="hsl(var(--background))"
    />
    {/* Eyes */}
    <circle cx="28" cy="32" r="1.1" fill="currentColor" />
    <circle cx="36" cy="32" r="1.1" fill="currentColor" />
  </svg>
);

export default Logo;
